import random
import time
from packing import get_encrypted_bits, get_decrypted_number, get_constant

n = 2
t, bound = get_constant()
enc_bits_list = []
st = time.time()
for i in range(n):
    r_list = []
    for i in range(t):
        # random float r
        r = random.uniform(-bound, bound)
        r_list.append(r)
    enc_bits_list.append(get_encrypted_bits(r_list))
print("Encrypt Time: %.6f ms/op" % ((time.time() - st) * 1000 / (n * t)))

st = time.time()
enc_sum = sum(enc_bits_list)
print("Add Time: %.6f ms/op" % ((time.time() - st) * 1000 / ((n - 1) * t)))

st = time.time()
sum_list = get_decrypted_number(enc_sum, n)
print("Decrypt Time: %.6f ms/op" % ((time.time() - st) * 1000 / t))
print(sum_list)