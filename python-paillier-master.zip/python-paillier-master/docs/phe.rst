API Documentation
=================


Paillier
--------


.. automodule:: phe.paillier
    :members:
    :undoc-members:
    :show-inheritance:

Encoding
--------

.. automodule:: phe.encoding
    :members:
    :undoc-members:
    :show-inheritance:



Utilities
---------


.. automodule:: phe.util
    :members:
    :undoc-members:
    :show-inheritance:

