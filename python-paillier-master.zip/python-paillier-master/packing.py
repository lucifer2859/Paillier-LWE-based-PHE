import phe as paillier
import math

# 公钥pk,私钥sk
pk, sk = paillier.generate_paillier_keypair()
# 最大明文长度
max_bit = math.floor(math.log(pk.n, 2))
# 精度prec,填充pad
prec, pad = 15, 1
# 单个数据大小
data_size = prec + pad
# 明文可容纳的数据数目
t = math.floor(max_bit / data_size)
# 浮点数输入的上下界
LOG2_BOUND = 1
bound = 2 ** LOG2_BOUND

# 获取常数
def get_constant():
    return t, bound

# 打包加密
# arg1: 浮点数列表
def get_encrypted_bits(r_list):
    pack_bits = ''
    for i, r in enumerate(r_list):
        # float to int
        int_r = math.floor((r + bound) * 2 ** (prec - LOG2_BOUND - 1))
        # packing data in encryption
        pack_bits += bin(int_r)[2:].zfill(prec)
        if i != t - 1:
            zero_pad = '0'
            pack_bits += zero_pad.zfill(pad)
    return pk.encrypt(int('0b' + pack_bits, 2))

# 解密拆包，
# arg1: 打包的密文
# arg2: 加数数目
def get_decrypted_number(pack_ciphertext, n):
    total_sum_bits = bin(sk.decrypt(pack_ciphertext))[2:].zfill(t * data_size)
    idx = 0
    sum_list = []
    for i in range(t):
        int_sum = int('0b' + total_sum_bits[idx: idx + data_size], 2)
        sum_list.append(int_sum / 2 ** (prec - LOG2_BOUND - 1) - n * bound)
        idx += data_size
    return sum_list